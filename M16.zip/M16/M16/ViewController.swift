//
//  ViewController.swift
//  M16
//
//  Created by Варвара Марченко on 15.07.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("Test")
        // Do any additional setup after loading the view.
    }


}

